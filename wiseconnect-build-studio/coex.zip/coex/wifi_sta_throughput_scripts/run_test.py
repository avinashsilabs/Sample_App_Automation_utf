"""
run_test.py

Wi-Fi Coex - Wi-Fi Client BLE Throughput App

Topology
--------

                         +----------------------+
                         |         PC           |
                         |     run_test.py      |
                         +----------+-----------+
                                    |
                   +----------------+----------------+
                   |                                 |
                   | Studio API                      | SSH
                   v                                 v
          +------------------+              +------------------+
          |     SiWG917      |              |  Raspberry Pi 4  |
          |       DUT        |              |                  |
          |                  |              | BLE Central      |
          | BLE Peripheral   |<-------------| iPerf UDP Server |
          | Wi-Fi Station    |   BLE        |                  |
          | UDP_TX Client    |              +------------------+
          +------------------+

Test flow
---------

1. Load config.local.json
2. Configure wifi_config.h
3. Configure BLE device name in ble_app.c
4. Start iPerf UDP server on Raspberry Pi
5. Build and flash DUT through existing StudioApi
6. Start DUT serial watcher
7. Start Raspberry Pi BLE Central
8. Pi scans for SI_COEX_MAX_DEMO
9. Pi connects to DUT
10. Pi discovers GATT services
11. Pi subscribes to notification UUID
12. BLE connection remains alive
13. DUT connects to WLAN
14. DUT starts UDP_TX throughput
15. Collect throughput result
16. Stop BLE Central
17. Stop iPerf
18. Write last_result.json
19. Return PASS/FAIL

Important
---------

- DUT = BLE Peripheral
- Raspberry Pi = BLE Central
- No second BLE peer
- No DUT-as-Central operation
- Existing common.harness.StudioApi is used
- No guessed /api/build_flash endpoint
"""

import base64
import json
import re
import shlex
import sys
import time

from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any


# ---------------------------------------------------------------------------
# Paths / imports
# ---------------------------------------------------------------------------

HERE = Path(__file__).resolve().parent

# common/ is one directory above this script directory
sys.path.insert(0, str(HERE.parent))

from common.harness import SerialWatcher, StudioApi
from common.pi_ble import _connect, _run


APP_ID = "wifi_station_ble_throughput_app"


# ---------------------------------------------------------------------------
# Test state
# ---------------------------------------------------------------------------

@dataclass
class TestState:
    wlan_connected: bool = False
    ble_connected: bool = False
    ble_notification_received: bool = False
    udp_started: bool = False
    udp_result: str = ""
    failure: str = ""


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

def log(message: str) -> None:
    print(message, flush=True)


def fail(
    state: TestState,
    message: str,
) -> None:
    if not state.failure:
        state.failure = message

    log(f"[FAIL] {message}")


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

def load_throughput_config(
    path: Path,
) -> dict[str, Any]:

    if not path.exists():
        raise FileNotFoundError(
            f"Configuration file not found:\n{path}"
        )

    with path.open(
        "r",
        encoding="utf-8",
    ) as f:
        cfg = json.load(f)

    required = (
        "studio",
        "wifi",
        "pi",
        "udp",
        "ble",
    )

    missing = [
        section
        for section in required
        if section not in cfg
    ]

    if missing:
        raise KeyError(
            "Missing configuration sections: "
            + ", ".join(missing)
        )

    return cfg


# ---------------------------------------------------------------------------
# C source helpers
# ---------------------------------------------------------------------------

def replace_define(
    text: str,
    name: str,
    value: str,
    *,
    required: bool = True,
) -> tuple[str, bool]:

    pattern = (
        rf"^(\s*#define\s+"
        rf"{re.escape(name)}\s+).*$"
    )

    replacement = rf"\g<1>{value}"

    new_text, count = re.subn(
        pattern,
        replacement,
        text,
        flags=re.MULTILINE,
    )

    if count == 0 and required:
        raise RuntimeError(
            f"#define {name} was not found in source file"
        )

    return new_text, count > 0


def find_source_file(
    root: Path,
    filename: str,
) -> Path:

    direct = root / filename

    if direct.exists():
        return direct

    matches = list(
        root.rglob(filename)
    )

    if not matches:
        raise FileNotFoundError(
            f"Could not find {filename} under:\n{root}"
        )

    # Prefer the shortest path.
    matches.sort(
        key=lambda p: len(p.parts)
    )

    return matches[0]


# ---------------------------------------------------------------------------
# Wi-Fi configuration
# ---------------------------------------------------------------------------

def security_macro(
    security: Any,
) -> str:

    if isinstance(security, str):

        normalized = security.strip().upper()

        if normalized in {
            "SL_WIFI_WPA2",
            "WPA2",
            "2",
        }:
            return "SL_WIFI_WPA2"

        if normalized in {
            "SL_WIFI_WPA",
            "WPA",
            "1",
        }:
            return "SL_WIFI_WPA"

        if normalized in {
            "SL_WIFI_OPEN",
            "OPEN",
            "0",
        }:
            return "SL_WIFI_OPEN"

    try:
        security_int = int(security)

    except (
        TypeError,
        ValueError,
    ) as exc:

        raise ValueError(
            "Unsupported Wi-Fi security value: "
            f"{security!r}"
        ) from exc

    mapping = {
        0: "SL_WIFI_OPEN",
        1: "SL_WIFI_WPA",
        2: "SL_WIFI_WPA2",
    }

    if security_int not in mapping:
        raise ValueError(
            "Unsupported Wi-Fi security value: "
            f"{security!r}"
        )

    return mapping[security_int]


def configure_wifi_source(
    cfg: dict[str, Any],
) -> Path:

    root = (
        Path(
            cfg["studio"]["examples_root"]
        )
        / APP_ID
    )

    if not root.exists():
        raise FileNotFoundError(
            f"Application directory does not exist:\n{root}"
        )

    header = find_source_file(
        root,
        "wifi_config.h",
    )

    log(
        f"[config] Wi-Fi config: {header}"
    )

    text = header.read_text(
        encoding="utf-8"
    )

    wifi_cfg = cfg["wifi"]
    udp_cfg = cfg["udp"]

    ssid = str(
        wifi_cfg["ssid"]
    )

    password = str(
        wifi_cfg["password"]
    )

    security = security_macro(
        wifi_cfg.get(
            "security",
            2,
        )
    )

    # If server_ip is empty, Pi is the UDP server.
    server_ip = (
        udp_cfg.get("server_ip")
        or cfg["pi"]["host"]
    )

    server_port = int(
        udp_cfg.get(
            "server_port",
            5001,
        )
    )

    # device_port is optional in config.
    # For compatibility, use server_port if absent.
    device_port = int(
        udp_cfg.get(
            "device_port",
            server_port,
        )
    )

    socket_async_feature = int(
        udp_cfg.get(
            "socket_async_feature",
            1,
        )
    )

    throughput_type = str(
        udp_cfg.get(
            "throughput_type",
            "UDP_TX",
        )
    ).upper()

    replacements = {
        "SSID": json.dumps(ssid),
        "PSK": json.dumps(password),
        "SECURITY_TYPE": security,
        "DEVICE_PORT": str(device_port),
        "SERVER_PORT": str(server_port),
        "SERVER_IP_ADDRESS": json.dumps(server_ip),
        "SOCKET_ASYNC_FEATURE": str(
            socket_async_feature
        ),
        "THROUGHPUT_TYPE": throughput_type,
    }

    for name, value in replacements.items():

        text, _ = replace_define(
            text,
            name,
            value,
            required=True,
        )

    # Optional dynamic BLE throughput macro.
    dynamic_value = int(
        udp_cfg.get(
            "ble_dynamic_disable_throughput_demo",
            0,
        )
    )

    text, found_dynamic = replace_define(
        text,
        "SL_BLE_DYNAMIC_DISABLE_THROUGHPUT_DEMO",
        str(dynamic_value),
        required=False,
    )

    # README says dynamic mode and continuous throughput
    # should not be enabled together.
    if found_dynamic and dynamic_value == 1:

        text, _ = replace_define(
            text,
            "CONTINUOUS_THROUGHPUT",
            "0",
            required=False,
        )

    header.write_text(
        text,
        encoding="utf-8",
    )

    log(
        "[config] Wi-Fi configured: "
        f"SSID={ssid}, "
        f"security={security}, "
        f"server={server_ip}:{server_port}, "
        f"type={throughput_type}"
    )

    return header


# ---------------------------------------------------------------------------
# BLE configuration
# ---------------------------------------------------------------------------

def configure_ble_source(
    cfg: dict[str, Any],
) -> Path:
    """
    Configure the DUT BLE peripheral.

    IMPORTANT:
    The README describes RSI_BLE_* macro names, but the actual
    ble_app.c in the current SDK/application does not contain
    RSI_BLE_CHAR_SERV_UUID.

    Therefore we do NOT require those README macro names.

    The automation requirement is:

        DUT advertising name = SI_COEX_MAX_DEMO

    The Pi-side BLE Central uses the configured notification UUID.
    """

    root = (
        Path(
            cfg["studio"]["examples_root"]
        )
        / APP_ID
    )

    source = find_source_file(
        root,
        "ble_app.c",
    )

    log(
        f"[config] BLE config: {source}"
    )

    text = source.read_text(
        encoding="utf-8"
    )

    ble_cfg = cfg["ble"]

    device_name = str(
        ble_cfg.get(
            "device_name",
            "SI_COEX_MAX_DEMO",
        )
    )

    notify_uuid = str(
        ble_cfg.get(
            "notify_uuid",
            "00001aa1-0000-1000-8000-00805f9b34fb",
        )
    )

    # ---------------------------------------------------------------
    # Known BLE device-name macros.
    # Only modify a macro if it actually exists.
    # ---------------------------------------------------------------

    device_name_macros = (
        "RSI_BLE_DEVICE_NAME",
        "BLE_DEVICE_NAME",
        "DEVICE_NAME",
        "RSI_BLE_DEV_NAME",
    )

    name_updated = False

    for macro in device_name_macros:

        text, found = replace_define(
            text,
            macro,
            json.dumps(device_name),
            required=False,
        )

        if found:

            log(
                "[config] BLE device name updated: "
                f"{macro}={device_name}"
            )

            name_updated = True
            break

    # ---------------------------------------------------------------
    # If no known macro exists, replace only known application
    # device-name strings.
    #
    # Do not touch arbitrary UUID/service strings.
    # ---------------------------------------------------------------

    if not name_updated:

        known_names = (
            "BLE_THROUGHPUT_APP",
            "BLE_CONFIGURATOR",
            "SI_COEX_MAX_DEMO",
        )

        for old_name in known_names:

            pattern = (
                rf'(?P<quote>["\'])'
                rf'{re.escape(old_name)}'
                rf'(?P=quote)'
            )

            new_text, count = re.subn(
                pattern,
                json.dumps(device_name),
                text,
                count=1,
            )

            if count:

                text = new_text
                name_updated = True

                log(
                    "[config] BLE device name string "
                    f"updated to {device_name}"
                )

                break

    # ---------------------------------------------------------------
    # Do not fail if the device-name definition is not one of the
    # known formats.
    #
    # In that case preserve the source and let the scan stage verify
    # the actual advertising name.
    # ---------------------------------------------------------------

    if not name_updated:

        log(
            "[config] BLE device-name definition was not found "
            "using known patterns."
        )

        log(
            "[config] Existing BLE source preserved."
        )

        log(
            "[config] Expected DUT advertising name: "
            f"{device_name}"
        )

    source.write_text(
        text,
        encoding="utf-8",
    )

    log(
        "[config] BLE source configuration complete"
    )

    log(
        "[config] DUT role    : BLE Peripheral"
    )

    log(
        "[config] Pi role     : BLE Central"
    )

    log(
        "[config] Target name : "
        f"{device_name}"
    )

    log(
        "[config] Notify UUID : "
        f"{notify_uuid}"
    )

    return source


def configure_source(
    cfg: dict[str, Any],
) -> tuple[Path, Path]:

    wifi_header = configure_wifi_source(
        cfg
    )

    ble_source = configure_ble_source(
        cfg
    )

    return (
        wifi_header,
        ble_source,
    )


# ---------------------------------------------------------------------------
# Raspberry Pi iPerf UDP server
# ---------------------------------------------------------------------------

def start_udp_server(
    cfg: dict[str, Any],
):
    """
    Start iPerf UDP server on Raspberry Pi.
    """

    pi_cfg = cfg["pi"]
    udp_cfg = cfg["udp"]

    host = pi_cfg["host"]
    port = int(
        udp_cfg.get(
            "server_port",
            5001,
        )
    )

    workdir = pi_cfg.get(
        "remote_workdir",
        "/var/tmp/wcbs_throughput",
    )

    pid_file = (
        f"{workdir}/wcbs_iperf_udp.pid"
    )

    log_file = (
        f"{workdir}/wcbs_iperf_udp.log"
    )

    log(
        "[pi] Connecting to Raspberry Pi "
        f"{host}:{pi_cfg.get('port', 22)}"
    )

    client = _connect(
        host,
        int(
            pi_cfg.get(
                "port",
                22,
            )
        ),
        pi_cfg["username"],
        pi_cfg["password"],
    )

    _run(
        client,
        f"mkdir -p {shlex.quote(workdir)}",
    )

    # Check whether iperf exists.
    result = _run(
        client,
        "command -v iperf || true",
    )

    iperf_path = str(result).strip()

    if not iperf_path:

        if not udp_cfg.get(
            "install_iperf_if_missing",
            True,
        ):

            raise RuntimeError(
                "iperf is not installed on Raspberry Pi "
                "and installation is disabled"
            )

        log(
            "[pi] iperf not found; attempting installation"
        )

        install_result = _run(
            client,
            "sudo apt-get update && "
            "sudo apt-get install -y iperf",
        )

        log(
            f"[pi] iperf install result: "
            f"{install_result}"
        )

    # Kill any previous test instance.
    _run(
        client,
        "if [ -f "
        f"{shlex.quote(pid_file)}"
        " ]; then "
        "kill $(cat "
        f"{shlex.quote(pid_file)}"
        ") 2>/dev/null || true; "
        "fi",
    )

    _run(
        client,
        "pkill -f "
        "'iperf -s -u' "
        "2>/dev/null || true",
    )

    # Remove stale files.
    _run(
        client,
        f"rm -f "
        f"{shlex.quote(pid_file)} "
        f"{shlex.quote(log_file)}",
    )

    command = (
        f"nohup iperf "
        f"-s -u "
        f"-p {port} "
        f"-i 1 "
        f"> {shlex.quote(log_file)} "
        f"2>&1 & "
        f"echo $! > {shlex.quote(pid_file)}"
    )

    _run(
        client,
        command,
    )

    time.sleep(1)

    pid_result = _run(
        client,
        f"cat {shlex.quote(pid_file)} "
        "2>/dev/null || true",
    )

    pid = str(
        pid_result
    ).strip()

    if not pid:

        raise RuntimeError(
            "Failed to obtain iPerf PID"
        )

    log(
        "[pi] iPerf UDP server started: "
        f"port={port}, pid={pid}"
    )

    # Verify process.
    process_result = _run(
        client,
        f"ps -p {shlex.quote(pid)} "
        "-o pid=,cmd= "
        "2>/dev/null || true",
    )

    if not str(process_result).strip():

        log_result = _run(
            client,
            f"cat {shlex.quote(log_file)} "
            "2>/dev/null || true",
        )

        raise RuntimeError(
            "iPerf process exited immediately.\n"
            f"{log_result}"
        )

    # Verify UDP socket if ss is available.
    socket_result = _run(
        client,
        f"ss -lunp 2>/dev/null | "
        f"grep ':{port} ' || true",
    )

    if str(socket_result).strip():

        log(
            "[pi] UDP socket confirmed: "
            f"{socket_result}"
        )

    else:

        log(
            "[pi] UDP socket verification "
            "did not return a matching line; "
            "continuing because process is alive."
        )

    return (
        client,
        pid,
        log_file,
    )


def stop_udp_server(
    client,
    pid: str | None,
    cfg: dict[str, Any],
) -> None:

    if client is None:
        return

    pi_cfg = cfg["pi"]

    workdir = pi_cfg.get(
        "remote_workdir",
        "/var/tmp/wcbs_throughput",
    )

    log_file = (
        f"{workdir}/wcbs_iperf_udp.log"
    )

    pid_file = (
        f"{workdir}/wcbs_iperf_udp.pid"
    )

    if pid:

        _run(
            client,
            f"kill {shlex.quote(str(pid))} "
            "2>/dev/null || true",
        )

    _run(
        client,
        "pkill -f "
        "'iperf -s -u' "
        "2>/dev/null || true",
    )

    final_log = _run(
        client,
        f"cat {shlex.quote(log_file)} "
        "2>/dev/null || true",
    )

    if str(final_log).strip():

        log(
            "[pi] Final iPerf log:\n"
            + str(final_log)
        )

    _run(
        client,
        f"rm -f {shlex.quote(pid_file)}",
    )

    try:
        client.close()
    except Exception:
        pass

    log(
        "[pi] iPerf UDP server stopped"
    )


# ---------------------------------------------------------------------------
# Raspberry Pi BLE Central
# ---------------------------------------------------------------------------

BLE_CENTRAL_SCRIPT = r'''
import asyncio
import time

from bleak import BleakClient, BleakScanner


DEVICE_NAME = __DEVICE_NAME__
DEVICE_ADDRESS = __DEVICE_ADDRESS__
NOTIFY_UUID = __NOTIFY_UUID__

SCAN_TIMEOUT = __SCAN_TIMEOUT__
NOTIFICATION_WINDOW = __NOTIFICATION_WINDOW__
HOLD_TIME = __HOLD_TIME__


async def find_device():

    print(
        f"[pi-ble] Scanning for "
        f"{DEVICE_ADDRESS or DEVICE_NAME} "
        f"({SCAN_TIMEOUT}s)...",
        flush=True,
    )

    devices = await BleakScanner.discover(
        timeout=SCAN_TIMEOUT
    )

    for device in devices:

        name = (
            getattr(device, "name", None)
            or getattr(device, "local_name", None)
            or ""
        )

        address = getattr(
            device,
            "address",
            "",
        )

        if DEVICE_ADDRESS:

            if (
                address.lower()
                == DEVICE_ADDRESS.lower()
            ):

                print(
                    f"[pi-ble] Found {name} "
                    f"address={address}",
                    flush=True,
                )

                return device

        elif name == DEVICE_NAME:

            print(
                f"[pi-ble] Found {name} "
                f"address={address}",
                flush=True,
            )

            return device

    raise RuntimeError(
        "BLE target was not found: "
        + (
            DEVICE_ADDRESS
            or DEVICE_NAME
        )
    )


async def main():

    device = await find_device()

    notification_event = (
        asyncio.Event()
    )

    notification_count = 0

    def notification_handler(
        sender,
        data,
    ):

        nonlocal notification_count

        notification_count += 1

        print(
            "[pi-ble] Notification "
            f"{notification_count}: "
            f"{bytes(data).hex()}",
            flush=True,
        )

        notification_event.set()

    address = getattr(
        device,
        "address",
        device,
    )

    print(
        f"[pi-ble] Connecting to "
        f"{address}...",
        flush=True,
    )

    async with BleakClient(
        device,
        timeout=SCAN_TIMEOUT,
    ) as client:

        if not client.is_connected:

            raise RuntimeError(
                "BleakClient reports disconnected"
            )

        print(
            "[pi-ble] BLE_CONNECTED",
            flush=True,
        )

        print(
            "[pi-ble] Discovering GATT services...",
            flush=True,
        )

        notify_characteristic = None

        for service in client.services:

            print(
                f"[pi-ble] Service: "
                f"{service.uuid}",
                flush=True,
            )

            for characteristic in (
                service.characteristics
            ):

                print(
                    "[pi-ble] Characteristic: "
                    f"{characteristic.uuid} "
                    f"properties="
                    f"{characteristic.properties}",
                    flush=True,
                )

                if (
                    characteristic.uuid.lower()
                    == NOTIFY_UUID.lower()
                ):

                    notify_characteristic = (
                        characteristic
                    )

        if notify_characteristic is None:

            raise RuntimeError(
                "Configured notification UUID "
                "was not found: "
                f"{NOTIFY_UUID}"
            )

        properties = [
            str(p).lower()
            for p in (
                notify_characteristic.properties
            )
        ]

        if "notify" not in properties:

            raise RuntimeError(
                "Configured characteristic does "
                "not support notify: "
                f"{NOTIFY_UUID}"
            )

        print(
            "[pi-ble] Subscribing to "
            f"{NOTIFY_UUID}...",
            flush=True,
        )

        await client.start_notify(
            notify_characteristic,
            notification_handler,
        )

        print(
            "[pi-ble] BLE_READY",
            flush=True,
        )

        print(
            "[pi-ble] Waiting for notification...",
            flush=True,
        )

        try:

            await asyncio.wait_for(
                notification_event.wait(),
                timeout=NOTIFICATION_WINDOW,
            )

        except asyncio.TimeoutError:

            print(
                "[pi-ble] No notification received "
                f"within {NOTIFICATION_WINDOW}s",
                flush=True,
            )

        if notification_count:

            print(
                "[pi-ble] "
                "BLE_NOTIFICATION_RECEIVED",
                flush=True,
            )

        else:

            print(
                "[pi-ble] "
                "BLE_NOTIFICATION_NOT_RECEIVED",
                flush=True,
            )

        print(
            "[pi-ble] Holding BLE connection "
            f"for {HOLD_TIME}s...",
            flush=True,
        )

        deadline = (
            time.monotonic()
            + HOLD_TIME
        )

        while (
            time.monotonic()
            < deadline
        ):

            if not client.is_connected:

                raise RuntimeError(
                    "BLE connection dropped during "
                    "throughput test"
                )

            await asyncio.sleep(1)

        try:

            await client.stop_notify(
                notify_characteristic
            )

        except Exception as exc:

            print(
                "[pi-ble] stop_notify warning: "
                f"{exc}",
                flush=True,
            )

        print(
            "[pi-ble] BLE_CENTRAL_DONE",
            flush=True,
        )

        if not client.is_connected:

            raise RuntimeError(
                "BLE disconnected before test completion"
            )

    print(
        "[pi-ble] BLE_CENTRAL_PASS",
        flush=True,
    )


if __name__ == "__main__":

    try:

        asyncio.run(main())

    except Exception as exc:

        print(
            "[pi-ble] BLE_CENTRAL_FAIL: "
            f"{exc}",
            flush=True,
        )

        raise
'''


def build_ble_script(
    cfg: dict[str, Any],
) -> str:

    ble_cfg = cfg["ble"]

    timeout_cfg = cfg.get(
        "timeouts",
        {},
    )

    device_name = str(
        ble_cfg.get(
            "device_name",
            "SI_COEX_MAX_DEMO",
        )
    )

    device_address = str(
        ble_cfg.get(
            "address",
            "",
        )
    )

    notify_uuid = str(
        ble_cfg.get(
            "notify_uuid",
            "00001aa1-0000-1000-8000-00805f9b34fb",
        )
    )

    scan_timeout = float(
        ble_cfg.get(
            "connect_timeout_s",
            30,
        )
    )

    notification_window = float(
        ble_cfg.get(
            "notification_window_s",
            8,
        )
    )

    # BLE must remain connected through WLAN + UDP test.
    default_hold_time = (
        float(
            timeout_cfg.get(
                "wlan_s",
                90,
            )
        )
        +
        float(
            timeout_cfg.get(
                "udp_s",
                90,
            )
        )
        +
        30
    )

    hold_time = float(
        ble_cfg.get(
            "connection_hold_s",
            default_hold_time,
        )
    )

    replacements = {
        "__DEVICE_NAME__": repr(
            device_name
        ),
        "__DEVICE_ADDRESS__": repr(
            device_address
        ),
        "__NOTIFY_UUID__": repr(
            notify_uuid
        ),
        "__SCAN_TIMEOUT__": repr(
            scan_timeout
        ),
        "__NOTIFICATION_WINDOW__": repr(
            notification_window
        ),
        "__HOLD_TIME__": repr(
            hold_time
        ),
    }

    script = BLE_CENTRAL_SCRIPT

    for key, value in replacements.items():

        script = script.replace(
            key,
            value,
        )

    return script


# ---------------------------------------------------------------------------
# Pi file upload
# ---------------------------------------------------------------------------

def upload_text(
    client,
    remote_path: str,
    text: str,
) -> None:

    encoded = base64.b64encode(
        text.encode("utf-8")
    ).decode("ascii")

    command = (
        "echo "
        + shlex.quote(encoded)
        + " | base64 -d > "
        + shlex.quote(remote_path)
    )

    _run(
        client,
        command,
    )


# ---------------------------------------------------------------------------
# Start Pi BLE Central
# ---------------------------------------------------------------------------

def start_pi_ble_central(
    cfg: dict[str, Any],
):

    pi_cfg = cfg["pi"]

    host = pi_cfg["host"]

    port = int(
        pi_cfg.get(
            "port",
            22,
        )
    )

    username = pi_cfg["username"]
    password = pi_cfg["password"]

    workdir = pi_cfg.get(
        "remote_workdir",
        "/var/tmp/wcbs_throughput",
    )

    script_path = (
        f"{workdir}/wcbs_ble_central.py"
    )

    log_path = (
        f"{workdir}/wcbs_ble_central.log"
    )

    pid_path = (
        f"{workdir}/wcbs_ble_central.pid"
    )

    log(
        "[pi-ble] Connecting to Raspberry Pi "
        f"{host}:{port}"
    )

    client = _connect(
        host,
        port,
        username,
        password,
    )

    _run(
        client,
        f"mkdir -p {shlex.quote(workdir)}",
    )

    script = build_ble_script(
        cfg
    )

    upload_text(
        client,
        script_path,
        script,
    )

    # Ensure old BLE central process is gone.
    _run(
        client,
        f"if [ -f {shlex.quote(pid_path)} ]; "
        "then "
        f"kill $(cat {shlex.quote(pid_path)}) "
        "2>/dev/null || true; "
        "fi",
    )

    _run(
        client,
        "pkill -f "
        "'wcbs_ble_central.py' "
        "2>/dev/null || true",
    )

    _run(
        client,
        f"rm -f "
        f"{shlex.quote(log_path)} "
        f"{shlex.quote(pid_path)}",
    )

    command = (
        f"nohup python3 "
        f"{shlex.quote(script_path)} "
        f"> {shlex.quote(log_path)} "
        f"2>&1 & "
        f"echo $! > {shlex.quote(pid_path)}"
    )

    _run(
        client,
        command,
    )

    time.sleep(1)

    pid_result = _run(
        client,
        f"cat {shlex.quote(pid_path)} "
        "2>/dev/null || true",
    )

    pid = str(
        pid_result
    ).strip()

    if not pid:

        raise RuntimeError(
            "Failed to start Pi BLE Central"
        )

    log(
        "[pi-ble] BLE Central process started "
        f"pid={pid}"
    )

    return {
        "client": client,
        "pid": pid,
        "log": log_path,
        "script": script_path,
        "pid_file": pid_path,
    }


# ---------------------------------------------------------------------------
# Read Pi BLE log
# ---------------------------------------------------------------------------

def read_pi_ble_log(
    ble_proc,
) -> str:

    client = ble_proc["client"]
    log_path = ble_proc["log"]

    result = _run(
        client,
        f"cat {shlex.quote(log_path)} "
        "2>/dev/null || true",
    )

    return str(result)


# ---------------------------------------------------------------------------
# Wait for BLE ready
# ---------------------------------------------------------------------------

def wait_for_pi_ble_ready(
    ble_proc,
    timeout_s: float,
) -> tuple[bool, bool]:

    deadline = (
        time.monotonic()
        + timeout_s
    )

    connected = False
    notification_received = False

    last_log_length = 0

    while time.monotonic() < deadline:

        text = read_pi_ble_log(
            ble_proc
        )

        if (
            "BLE_CENTRAL_FAIL"
            in text
        ):

            raise RuntimeError(
                "Pi BLE Central failed:\n"
                + text
            )

        if (
            "BLE_CONNECTED"
            in text
        ) and not connected:

            connected = True

            log(
                "[pi-ble] BLE connection "
                "confirmed"
            )

        if (
            "BLE_NOTIFICATION_RECEIVED"
            in text
        ):

            notification_received = True

        if (
            "BLE_READY"
            in text
        ):

            log(
                "[pi-ble] BLE Central ready; "
                "BLE connection will remain active"
            )

            return (
                connected,
                notification_received,
            )

        # Print only newly appended log text.
        if len(text) > last_log_length:

            new_text = text[
                last_log_length:
            ]

            for line in new_text.splitlines():

                if line.strip():

                    log(line)

            last_log_length = len(text)

        time.sleep(1)

    final_log = read_pi_ble_log(
        ble_proc
    )

    raise TimeoutError(
        "Timed out waiting for Pi BLE Central "
        "to reach BLE_READY.\n"
        f"{final_log}"
    )


# ---------------------------------------------------------------------------
# Stop Pi BLE Central
# ---------------------------------------------------------------------------

def stop_pi_ble_central(
    ble_proc,
) -> None:

    if ble_proc is None:
        return

    client = ble_proc["client"]

    pid = ble_proc.get(
        "pid"
    )

    log_path = ble_proc["log"]

    pid_path = ble_proc.get(
        "pid_file"
    )

    try:

        if pid:

            _run(
                client,
                f"kill {shlex.quote(str(pid))} "
                "2>/dev/null || true",
            )

        _run(
            client,
            "pkill -f "
            "'wcbs_ble_central.py' "
            "2>/dev/null || true",
        )

        final_log = _run(
            client,
            f"cat {shlex.quote(log_path)} "
            "2>/dev/null || true",
        )

        if str(final_log).strip():

            log(
                "[pi-ble] Final BLE Central log:\n"
                + str(final_log)
            )

        if pid_path:

            _run(
                client,
                f"rm -f {shlex.quote(pid_path)}",
            )

    finally:

        try:
            client.close()
        except Exception:
            pass

    log(
        "[pi-ble] BLE Central stopped"
    )


# ---------------------------------------------------------------------------
# DUT serial parser
# ---------------------------------------------------------------------------

def parse(
    line: str,
    state: TestState,
) -> None:

    text = line.strip()

    if not text:
        return

    lower = text.lower()

    log(
        f"[dut] {text}"
    )

    # ---------------------------------------------------------------
    # BLE
    # ---------------------------------------------------------------

    ble_success_patterns = (
        "number of peripheral devices connected",
        "ble peripheral connected",
        "ble connection success",
        "ble connected",
        "peripheral connected",
    )

    if any(
        pattern in lower
        for pattern in ble_success_patterns
    ):

        state.ble_connected = True

    # ---------------------------------------------------------------
    # WLAN
    # ---------------------------------------------------------------

    wlan_success_patterns = (
        "wlan connection success",
        "wlan connected state",
        "wlan connected",
        "ip config is done",
        "ip configuration is done",
        "ip address:",
    )

    if any(
        pattern in lower
        for pattern in wlan_success_patterns
    ):

        state.wlan_connected = True

    # ---------------------------------------------------------------
    # UDP throughput start
    # ---------------------------------------------------------------

    udp_start_patterns = (
        "udp_tx throughput test start",
        "udp tx throughput test start",
        "udp_tx throughput",
        "udp tx throughput",
        "throughput test start",
        "starting throughput",
    )

    if any(
        pattern in lower
        for pattern in udp_start_patterns
    ):

        state.udp_started = True

    # ---------------------------------------------------------------
    # Throughput result
    # ---------------------------------------------------------------

    throughput_match = re.search(
        r"throughput.*?"
        r"([0-9]+(?:\.[0-9]+)?)"
        r"\s*"
        r"(mbps|kbps|mbit|kbit)",
        lower,
    )

    if throughput_match:

        value = throughput_match.group(
            1
        )

        unit = throughput_match.group(
            2
        )

        state.udp_result = (
            f"{value} {unit}"
        )

    # ---------------------------------------------------------------
    # Failure patterns
    # ---------------------------------------------------------------

    failure_patterns = (
        "wlan connection failed",
        "wlan connect failed",
        "wlan connection fail",
        "ip config failed",
        "ip configuration failed",
        "socket create failed",
        "socket connect failed",
        "udp tx failed",
        "udp throughput failed",
        "throughput test failed",
        "ble connection failed",
        "ble connect failed",
    )

    for pattern in failure_patterns:

        if pattern in lower:

            fail(
                state,
                f"DUT reported failure: {text}",
            )

            break


# ---------------------------------------------------------------------------
# Generic condition wait
# ---------------------------------------------------------------------------

def wait_for_condition(
    condition,
    timeout_s: float,
    description: str,
) -> bool:

    log(
        f"[wait] Waiting for {description} "
        f"({timeout_s:.1f}s)"
    )

    deadline = (
        time.monotonic()
        + timeout_s
    )

    while time.monotonic() < deadline:

        if condition():

            log(
                f"[wait] {description}: OK"
            )

            return True

        time.sleep(0.5)

    log(
        f"[wait] {description}: TIMEOUT"
    )

    return False


# ---------------------------------------------------------------------------
# Main test flow
# ---------------------------------------------------------------------------

def run(
    cfg: dict[str, Any],
) -> TestState:

    state = TestState()

    udp_client = None
    udp_pid = None

    ble_proc = None

    watcher = None

    try:

        # ============================================================
        # 1. Configure source
        # ============================================================

        configure_source(
            cfg
        )

        # ============================================================
        # 2. Start iPerf UDP server on Pi
        # ============================================================

        (
            udp_client,
            udp_pid,
            udp_log,
        ) = start_udp_server(
            cfg
        )

        # ============================================================
        # 3. Build / flash DUT
        #
        # IMPORTANT:
        # Use existing StudioApi implementation.
        # Do NOT call a guessed /api/build_flash endpoint.
        # ============================================================

        api = StudioApi(
            cfg["studio"].get(
                "url",
                "http://127.0.0.1:5050",
            )
        )

        log(
            "[studio] Checking Studio API health"
        )

        api.request(
            "GET",
            "/api/health",
        )

        log(
            "[studio] Studio API health OK"
        )

        log(
            f"[studio] Build/flash: {APP_ID}"
        )

        build = api.build_flash(
            APP_ID,
            cfg,
        )

        log(
            "[studio] Build/flash result: "
            f"{build}"
        )

        # ============================================================
        # 4. Start serial watcher
        # ============================================================

        watcher = SerialWatcher(
            api,
            state,
            parse,
        )

        watcher.start()

        log(
            "[dut] Serial watcher started"
        )

        # ============================================================
        # 5. Start Pi BLE Central
        #
        # BLE Central connects before WLAN.
        # The process stays alive throughout the WLAN/UDP test.
        # ============================================================

        ble_proc = start_pi_ble_central(
            cfg
        )

        ble_timeout = (
            float(
                cfg["ble"].get(
                    "connect_timeout_s",
                    30,
                )
            )
            + 30
        )

        (
            state.ble_connected,
            state.ble_notification_received,
        ) = wait_for_pi_ble_ready(
            ble_proc,
            ble_timeout,
        )

        if not state.ble_connected:

            fail(
                state,
                "Pi BLE Central did not confirm BLE connection",
            )

        # ============================================================
        # 6. Wait for DUT WLAN connection
        # ============================================================

        wlan_timeout = float(
            cfg.get(
                "timeouts",
                {},
            ).get(
                "wlan_s",
                90,
            )
        )

        if not wait_for_condition(
            lambda: state.wlan_connected,
            wlan_timeout,
            "DUT WLAN connection",
        ):

            fail(
                state,
                "DUT WLAN connection timeout",
            )

        # ============================================================
        # 7. Wait for UDP throughput start
        # ============================================================

        udp_timeout = float(
            cfg.get(
                "timeouts",
                {},
            ).get(
                "udp_s",
                90,
            )
        )

        if not wait_for_condition(
            lambda: state.udp_started,
            udp_timeout,
            "UDP_TX throughput start",
        ):

            fail(
                state,
                "UDP_TX throughput did not start",
            )

        # ============================================================
        # 8. Wait for throughput result
        # ============================================================

        average_time_ms = float(
            cfg["udp"].get(
                "average_time_ms",
                60000,
            )
        )

        result_timeout = (
            average_time_ms / 1000.0
        ) + 30

        if not wait_for_condition(
            lambda: bool(
                state.udp_result
            ),
            result_timeout,
            "UDP_TX throughput result",
        ):

            fail(
                state,
                "UDP_TX throughput result "
                "was not detected",
            )

        # ============================================================
        # 9. Final state validation
        # ============================================================

        if not state.ble_connected:

            fail(
                state,
                "BLE Central was not connected",
            )

        if not state.wlan_connected:

            fail(
                state,
                "WLAN did not connect",
            )

        if not state.udp_started:

            fail(
                state,
                "UDP_TX did not start",
            )

        if not state.udp_result:

            fail(
                state,
                "No throughput result detected",
            )

        # Notification is informational unless explicitly required.
        if state.ble_notification_received:

            log(
                "[ble] Notification received"
            )

        else:

            log(
                "[ble] No notification received "
                "during notification window; "
                "continuing because notification "
                "is not a mandatory pass criterion"
            )

        # ============================================================
        # 10. Save result
        # ============================================================

        result_file = (
            HERE / "last_result.json"
        )

        with result_file.open(
            "w",
            encoding="utf-8",
        ) as f:

            json.dump(
                asdict(state),
                f,
                indent=2,
            )

        log(
            f"[result] Saved: {result_file}"
        )

        return state

    except Exception as exc:

        fail(
            state,
            str(exc),
        )

        # Try to save failure result too.
        try:

            result_file = (
                HERE / "last_result.json"
            )

            with result_file.open(
                "w",
                encoding="utf-8",
            ) as f:

                json.dump(
                    asdict(state),
                    f,
                    indent=2,
                )

        except Exception as save_exc:

            log(
                "[result] Could not save failure "
                f"result: {save_exc}"
            )

        return state

    finally:

        # ============================================================
        # Cleanup BLE first
        # ============================================================

        if ble_proc is not None:

            try:

                stop_pi_ble_central(
                    ble_proc
                )

            except Exception as exc:

                log(
                    "[cleanup] BLE cleanup error: "
                    f"{exc}"
                )

        # ============================================================
        # Stop serial watcher
        # ============================================================

        if watcher is not None:

            try:

                watcher.stop()

            except Exception as exc:

                log(
                    "[cleanup] Serial watcher error: "
                    f"{exc}"
                )

        # ============================================================
        # Stop iPerf
        # ============================================================

        if udp_client is not None:

            try:

                stop_udp_server(
                    udp_client,
                    udp_pid,
                    cfg,
                )

            except Exception as exc:

                log(
                    "[cleanup] iPerf cleanup error: "
                    f"{exc}"
                )


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:

    config_file = (
        HERE / "config.local.json"
    )

    log(
        "=" * 72
    )

    log(
        "Wi-Fi Coex - Wi-Fi Client BLE Throughput"
    )

    log(
        "=" * 72
    )

    log(
        f"[config] {config_file}"
    )

    try:

        cfg = load_throughput_config(
            config_file
        )

        state = run(
            cfg
        )

        log(
            ""
        )

        log(
            "=" * 72
        )

        if state.failure:

            log(
                "FINAL RESULT: FAIL"
            )

            log(
                f"Reason: {state.failure}"
            )

            log(
                "=" * 72
            )

            return 1

        log(
            "FINAL RESULT: PASS"
        )

        if state.udp_result:

            log(
                f"Throughput: "
                f"{state.udp_result}"
            )

        log(
            f"BLE connected: "
            f"{state.ble_connected}"
        )

        log(
            f"WLAN connected: "
            f"{state.wlan_connected}"
        )

        log(
            f"UDP started: "
            f"{state.udp_started}"
        )

        log(
            "=" * 72
        )

        return 0

    except Exception as exc:

        log(
            ""
        )

        log(
            "=" * 72
        )

        log(
            "FINAL RESULT: FAIL"
        )

        log(
            f"Exception: {exc}"
        )

        log(
            "=" * 72
        )

        return 1


if __name__ == "__main__":
    raise SystemExit(
        main()
    )